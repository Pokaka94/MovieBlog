package com.movie.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserInfoVo {
    private String userId;
    private String userPw;
    private String userNick;
    private String userPhone;
    private String userBirth;
    private String userSex;
    private String userEmail;
    private String userCreateDate;
}
