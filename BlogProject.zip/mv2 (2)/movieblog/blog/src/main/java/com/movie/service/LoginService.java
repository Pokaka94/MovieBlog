package com.movie.service;
import com.movie.dao.LoginDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    private final LoginDao loginDao;

    @Autowired
    public LoginService(LoginDao loginDao) {
        this.loginDao = loginDao;
    }

    public boolean login(String userId, String inputPw) {
        // 여기서 실제로 로그인 처리 로직을 구현합니다.
        String pw = loginDao.selectUserPw(userId);
        // 예시로 간단하게 "admin" 사용자명과 "password" 비밀번호를 검증합니다.
        if (inputPw.equals(pw)) {
            return true;
        } else {
            return false;
        }
    }
}