package com.example.sqltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
