package com.example.vo;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class UserVo {

}
