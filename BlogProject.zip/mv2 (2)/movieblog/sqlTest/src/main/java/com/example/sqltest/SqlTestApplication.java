package com.example.sqltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqlTestApplication.class, args);
	}

}
